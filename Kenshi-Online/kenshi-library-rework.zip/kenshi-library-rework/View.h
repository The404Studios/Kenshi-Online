#pragma once

#include <stdafx.h>

#include <ogre/OgreCamera.h>
#include <ogre/OgreSceneNode.h>

