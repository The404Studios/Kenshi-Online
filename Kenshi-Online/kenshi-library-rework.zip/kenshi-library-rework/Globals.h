#pragma once

class Item;

void  showErrorMessage();// RVA = 0x5CC110
float modMedicalSkill(float, Item*, float);// RVA = 0x4FC9E0