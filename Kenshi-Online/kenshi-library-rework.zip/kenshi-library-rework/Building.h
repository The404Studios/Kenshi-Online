#pragma once

// WindGeneratorBuilding extends GeneratorBuilding
// GeneratorBuilding extends ProductionBuilding
// CraftingBuilding extends ProductionBuilding
// FurnaceBuilding extends ProductionBuilding
// RainCollectorBuilding extends ProductionBuilding
// TortureBuilding extends ProductionBuilding
// FarmBuilding extends ProductionBuilding
// ProductionBuilding extends StorageBuilding
// StorageBuilding extends UsableStuff
// ResearchBuilding extends UsableStuff
// TurretBuilding extends UsableStuff
// UsableStuff extends Building
// LightBuilding extends Building
// DoorStuff extends Building
// WallBuilding extends Building
// GatewayBuilding extends Building
// Building extends RootObject, Ogre::AllocatedObject<Ogre::CategorisedAllocPolicy<0>>
struct Building
{

};